<?php
require "database-config.php";
require "functions.php";
//session_start();
?><!DOCTYPE html>
<html lang="en">
    <?php
     require "header.php"; 

    ?>
    <head>
        

    </head>
<body>

  <!-- preloader start -->
  <div id="preloader"></div>
  <!-- preloader end -->

  <!-- inner-page-banner-section start -->
  <section class="inner-page-banner-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="inner-page-banner-content text-center">
            <h2 class="title">Surveys</h2>
          </div>
          <nav aria-label="breadcrumb" class="page-header-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">surveys</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-page-banner-section end -->

  <!-- job-post-grid start  -->
  <div class="job-post-grid job-post-grid-style-one padd-top-120 padd-bottom-120">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="job-post-search-area">
          
            <form class="job-post-search-form" method="POST" action="search.php"> 
              <div class="row">
              
                <div class="col-lg-3">
                   <p>Your name:
                      
                   </p>
                   <input type="text" name="client-name" placeholder="Your name..." value="Anonymous" required>
                   <b>(Leave this field as it is if you would like to remain anonymous.) </b>
                </div>
                <div class="col-lg-3">
              
                  <div class="frm-group has_select">
                  
                  <p>Survey creators:</p>
                    

                    <select name='creator'>
                    <?php get_User($conn);?>
                      <!-- <option value="<?php //echo $array[$i]['fname'];?>"><?php //echo $array[$i]['fname']; ?></option>  -->
                    </select>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="frm-group">
             
            <input type="submit" name="submit" id="job_submit" value="search" >
                    
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>


      
  <!-- scroll-to-top end -->

  <!-- jquery library js file -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <!-- jquery migrate js file -->
  <script src="assets/js/jquery-migrate-3.0.0.js"></script>
  <!-- bootstrap js file -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- jquery waypoints js file -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- js file -->
  <script src="assets/js/jquery.countup.min.js"></script>
  <!-- jquery countup js file -->
  <script src="assets/js/lightcase.js"></script>
  <!-- js owl carousel file -->
  <script src="assets/js/owl.carousel.js"></script>
  <!-- wow js file -->
  <script src="assets/js/wow.min.js"></script>
  <!-- main js file -->
  <script src="assets/js/main.js"></script>
</body>
</html>
