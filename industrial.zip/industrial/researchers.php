<!DOCTYPE html>
<?php
     require "header.php"; 
?>
<html lang="en">
<head>
  
</head>
<body>

  <!-- preloader start -->
  <div id="preloader"></div>
  <!-- preloader end -->

  
  
  <!--  header-section end  -->
  <!-- inner-page-banner-section start -->
  <section class="inner-page-banner-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="inner-page-banner-content text-center">
            <h2 class="title">Researchers</h2>
          </div>
          <nav aria-label="breadcrumb" class="page-header-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">researchers</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-page-banner-section end -->

  <!-- resume-details-section start  -->
  <div class="resume-details-section padd-top-120 padd-bottom-120">
    <div class="container">
      <div class="row">
        <main class="col-lg-8">
          <div class="resume-details-wrapper">
            <div class="details-area">
              <div class="details-header">
                <div class="resume-single-item d-flex align-items-center">
                  <div class="thumb">
                    <img src="assets/images/dr_maria.jpg" alt="image">
                  </div>
                  <div class="content">
                    <h6 class="name">Dr Maria Tziraki</h6>
                    <ul class="resume-meta d-flex">
                      <li>Lecturer
Academic Director of Undergraduate Programmes</li>
                    </ul>
                    
                  </div>
                </div>
              </div>
              <div class="single-row">
                <div class="left">
                  <span class="row-title">Research Interests</span>
                </div>
                <div class="right">
                  <p>Dr Tziraki is interested in using imaging methods to construct biomarkers for neurodevelopmental disorders, understand the impact of traumatic brain injury on behaviour and explore the neural correlates of basic cognition. She has participated in a clinical trial for children with Neurofibromatosis 1 (NF1) syndromic autism, where by using multimodal MRI explored the impact of statin administration on brain and cognition. In addition, she participated in a project exploring with MRI the impact of traumatic brain injury on brain maturation and development in young people. She has worked as a research fellow in various UK labs and has extensive training and practical work in imaging and neuroscience research. </p>
                </div>
              </div>
              
              <div class="single-row">
                <div class="left">
                  <span class="row-title">Academic Position</span>
                </div>
                <div class="right">
                  <ul>
                    <li>Academic Director of Postgraduate Programmes in Neuropsychology Lecturer</li>
                  </ul>
                </div>
              </div>
              <div class="single-row">
                <div class="left">
                  <span class="row-title">Contact info</span>
                </div>
                <div class="right">
                  <ul>
                    <li><a href="mailto:mritzaki@citycollege.sheffield.eu">mritzaki@citycollege.sheffield.eu</a></li>
                  </ul>
                </div>
              </div>
            
            </div>
          </div>
        </main>
        
      </div>
    </div>
  </div>
    
    <div class="resume-details-section padd-top-120 padd-bottom-120">
    <div class="container">
      <div class="row">
        <main class="col-lg-8">
          <div class="resume-details-wrapper">
            <div class="details-area">
              <div class="details-header">
                <div class="resume-single-item d-flex align-items-center">
                  <div class="thumb">
                    <img src="assets/images/dr_ladas.jpg" alt="image">
                  </div>
                  <div class="content">
                    <h6 class="name">Dr Aristea Ladas</h6>
                    <ul class="resume-meta d-flex">
                      <li>Assistant Professor & Research Associate</li>
                    </ul>
                    
                  </div>
                </div>
              </div>
              <div class="single-row">
                <div class="left">
                  <span class="row-title">Research Interests</span>
                </div>
                <div class="right">
                  <p>Dr. Ladas completed her PhD in 2013 which was awarded by the University of Sheffield. Her topic was neuroplasticity and specifically the phenomenon of bilingualism and its effects on attention processes throughout the lifespan. She was a a scientific coordinator in the Long Lasting Memories project (European Commission) , investigating neuroplasticity in older individuals' brain, as well as a researcher in other projects funded by the European Commission. She has also collaborated with the Spanish University of Almeria, as  a researcher. Currently, she is a Honorary Lecturer at City College, the International Faculty of Sheffield University and a research associate of SEERC. She is also a Researcher at the Neuroscience Research Center (NEUREC), a research hab of CITY College, International Faculty of Sheffield University, as well as a Research Associate at the South East European Research Centre (SEERC), in the Cognitive Neuroscience Research Cluster. She is a Chartered Psychologist (CPsychol) of the British Psychological Society (BPS), a Fellow of the Higher Education Academy (UK) as well as a Member of the Association for Computing Machinery (ACM) Student Chapter. Moreover, she has worked with children with autism and learning difficulties . </p>
                </div>
              </div>
              
              <div class="single-row">
                <div class="left">
                  <span class="row-title">Academic Position</span>
                </div>
                <div class="right">
                  <ul>
                    <li>Research Projects Coordinator & Ethics for Research Coordinator</li>
                  </ul>
                </div>
              </div>
              <div class="single-row">
                <div class="left">
                  <span class="row-title">Contact info</span>
                </div>
                <div class="right">
                  <ul>
                    <li><a href="mailto:aladas@citycollege.sheffield.eu">aladas@citycollege.sheffield.eu</a></li>
                  </ul>
                </div>
              </div>
            
            </div>
          </div>
        </main>
        
      </div>
    </div>
  </div>
    
    
    <div class="resume-details-section padd-top-120 padd-bottom-120">
    <div class="container">
      <div class="row">
        <main class="col-lg-8">
          <div class="resume-details-wrapper">
            <div class="details-area">
              <div class="details-header">
                <div class="resume-single-item d-flex align-items-center">
                  <div class="thumb">
                    <img src="assets/images/resume/1.jpg" alt="image">
                  </div>
                  <div class="content">
                    <h6 class="name">3</h6>
                    <ul class="resume-meta d-flex">
                      <li>Front end developer</li>
                    </ul>
                    
                  </div>
                </div>
              </div>
              <div class="single-row">
                <div class="left">
                  <span class="row-title">Research Interests</span>
                </div>
                <div class="right">
                  <p>No info </p>
                </div>
              </div>
              
              <div class="single-row">
                <div class="left">
                  <span class="row-title">Academic Position</span>
                </div>
                <div class="right">
                  <ul>
                    <li>No info</li>
                  </ul>
                </div>
              </div>
              <div class="single-row">
                <div class="left">
                  <span class="row-title">Contact info</span>
                </div>
                <div class="right">
                  <ul>
                    <li><a href="mailto:mtziraki@citycollege.sheffield.eu"></a></li>
                  </ul>
                </div>
              </div>
            
            </div>
          </div>
        </main>
        
      </div>
    </div>
  </div>
  <!-- resume-details-section end  -->

  
  <!-- footer-section start -->
  <footer class="footer-section">
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-6">
            <div class="footer-widget widget-about wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">about us</h4>
              <div class="widget-about-body">
                  <p>Find us here</p>
                  </br>
                  <a class="site-logo site-title" href="https://citycollege.sheffield.eu/frontend/index.php?chlang=GR_ENl"><img src="assets/images/Collegelogo.png" alt="site-logo"><span class="logo-icon"><i class="flaticon-fire"></i></span></a>
                  
                 <ul class="social-links d-flex">
                  <li><a href="#0"><i class="fa fa-facebook-f"></i></a></li>
                  <li><a href="#0"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#0"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#0"><i class="fa fa-linkedin-square"></i></a></li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-3 col-sm-6">
           <div class="footer-widget widget-links wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">Researchers</h4>
              <ul class="links-list">
                <li><a href="#0">Dr. Maria's research</a></li>
                <li><a href="#0">Dr. Aristea's research</a></li>
                <li><a href="#0">Dr. Maria's research</a></li>
              </ul> 
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-3 col-sm-6">
            <div class="footer-widget widget-contact wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">contact us</h4>
              <div class="widget-contact-body">
                <ul>
                  <li>
                    <i class="fa fa-paper-plane"></i>
                      <a class="footer-maps" href="https://goo.gl/maps/pwwF4JmBSi8Axygx5" style="color:#92989b; text-align: inherit;">
                      
                      24, Proxenou Koromila Street,
                            546 22 Thessaloniki, Greece</a>
                  </li>
                </ul>
                  <ul>
                  <li>
                    <i class="fa fa-phone"></i>
                    <p style="font-weight:bold;">Contact us here</p>
                  </li>
                </ul>
                <a class="footer-phone" href="tel:016546545646">
                    +30 2310 224 421
                    </br>
                    +30 2310 224 521</a>
                <ul>
                  <li>
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                            <a href = "mailto: abc@bla.com" style="color:#92989b; text-align: inherit;">acadreg@citycollege.sheffield.eu</a>
                  </li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
        </div>
      </div>
    </div>

      
  </footer>
  <!-- footer-section end -->

  <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-angle-up"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->

  <!-- jquery library js file -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <!-- jquery migrate js file -->
  <script src="assets/js/jquery-migrate-3.0.0.js"></script>
  <!-- bootstrap js file -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- jquery waypoints js file -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- js file -->
  <script src="assets/js/jquery.countup.min.js"></script>
  <!-- jquery countup js file -->
  <script src="assets/js/lightcase.js"></script>
  <!-- js owl carousel file -->
  <script src="assets/js/owl.carousel.js"></script>
  <!-- wow js file -->
  <script src="assets/js/wow.min.js"></script>
  <!-- main js file -->
  <script src="assets/js/main.js"></script>
</body>
</html>