<?php
require "database-config.php";
require "functions.php";
    session_start();
if(isset($_SESSION["uid"]) && isset($_SESSION["loggedin"])){
    if(isset($_POST["submit"])){  
        $survey_name = $_POST["survey-name"];
        $survey_link = $_POST["survey-link"];
        $survey_desc = $_POST["survey-desc"];
        $uid = $_SESSION["uid"];
        upload_survey($conn,$uid,$survey_name,$survey_link,$survey_desc);
    }
else{
    header("location:user-profile.php");
    exit();
}
}else{
    header("location:user-profile.php");
    exit();
}

?>
