<?php
session_start();


//This is working properly.

// Establish or continue session
/*session_start([
  'cookie_lifetime' => 86400, // 24 hours
  'cookie_httponly' => true,  // Not accessible via JavaScript
  'read_and_close'  => true,  // Extract information and remove lock
]);
*/
   $client_name = $_SESSION["client_name"];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {


	

  // Decode transmitted data
  $data = json_decode(file_get_contents('php://input'), true);

  // (Cursory) validity check
  if (is_array($data)) {
    
    $file = fopen("dir/".'-'. $client_name .'-'.date('Y-m-d').'-'."stroop-data.txt", "w") or die("Unable to open file!");
    $mydata = json_encode($data['data']);
 
	fwrite($file,  $mydata);
	fclose($file);
	
	// ===========================================================//
  // ===========================================================//

$fcsv = fopen("dir/".'-'. $client_name .'-'.date('Y-m-d').'-'."stroop-data.csv", "w") or die("Unable to open file!");

$myFile = fopen("dir/".'-'. $client_name .'-'.date('Y-m-d').'-'."stroop-data.txt", "r") or die("Unable to open file!");

//$str = fread($myFile,"dir/".'-'. $client_name .'-'.date('Y-m-d').'-'."stroop-data.txt");

$str = file_get_contents("dir/".'-'. $client_name .'-'.date('Y-m-d').'-'."stroop-data.txt", true);

$array = json_decode($str, true);
$csv = '';
fclose($myFile);
$header = false;
foreach ($array as $line) { 
    if (empty($header)) {
        $header = array_keys($line);
        fputcsv($fcsv, $header);
        $header = array_flip($header);    
    }
  
  $line_array = array();
  
  foreach($line as $value) {
    array_push($line_array, $value);
  }

    fputcsv($fcsv, $line_array);
}

//close CSV file after write
fclose($fcsv);

















    
    http_response_code(200);
  } else {
    http_response_code(400);
  }

} else {
  http_response_code(405);
}

?>
