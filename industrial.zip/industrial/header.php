<!DOCTYPE html>
<?php 
session_start();
//echo $_SESSION["uid"];
?>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="icon" type="image/png" href="assets/images/favicon.png" sizes="16x16">
        <!-- fontawesome css file -->
        <link rel="stylesheet" href="assets/css/fontawesome.min.css">
        <!-- flaticon css file -->
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <!-- bootstrap css file -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- animate css file -->
        <link rel="stylesheet" href="assets/css/animate.css">
        <!-- lightcase css file -->
        <link rel="stylesheet" href="assets/css/lightcase.css">
        <!-- owl carousel css file -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    </head> 

<body>
 <!--  header-section start  -->
  <header class="header-section">
    <div class="header-top">
      <div class="container">
        <div class="row">
         
          <div class="col-lg-6 col-md-6 col-sm-8">
            <div class="header-top-right d-flex justify-content-end">
              <div class="lag-area">
                
              </div>
              <div class="account-area">
              
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="header-bottom">
      <div class="container">
          <nav class="navbar navbar-expand-xl p-0">
            <a class="site-logo site-title" href="index.php"><img src="assets/images/Collegelogo.png" alt="site-logo" style="
    padding-top: 20px;"><span class="logo-icon"><i class="flaticon-fire"></i></span></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="menu-toggle"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav main-menu ml-auto">
				  <li><a href="index.php">Home</a></li>
                  <li ><a href="researchers.php">Researchers</a>
                  <li ><a href="surveys.php">Take A Survey</a></li>
                   <li><a href="contact.php">Contact us</a></li>
                  <?php if(isset($_SESSION["uid"])){ ?>
                    <li><a href="user-profile.php">My Profile</a></li>
                    <li class="logout.php"><a href="logout.php">Log out</a></li>
                  <?php } else {?>
				          <li class="registration.html"><a href="register-page.php">Register</a></li>
                  <li class="login-page.html"><a href="login-page.php">Log in</a>
                  <?php } ?>
                 
              </ul>
            </div>
          </nav>
      </div>
    </div><!-- header-bottom end -->
  </header>
  </body>
</html>