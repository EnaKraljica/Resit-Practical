<?php
    require "database-config.php";
    require "functions.php";
    session_start();
?>
    <?php
     require "header.php"; 
    ?>
    <head>

    </head>
<!-- inner-page-banner-section start -->
  <section class="inner-page-banner-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="inner-page-banner-content text-center">
            <h2 class="title">Surveys</h2>
          </div>
          <nav aria-label="breadcrumb" class="page-header-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">surveys</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-page-banner-section end -->

  <!-- job-post-grid start  -->
  <div class="job-post-grid job-post-grid-style-one padd-top-120 padd-bottom-120">
    <form class="job-post-search-form" method="POST" action="search.php"> 
              <div class="row">
                <div class="col-lg-3">
                  
                </div>
                <div class="col-lg-3">
                  <div class="frm-group has_select">
                    <select name='creator'>
                       <?php get_User($conn);?>
                    </select>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="frm-group">
                    <input type="submit" name="submit" id="job_submit" value="search">
                  </div>
                </div>
              </div>
            </form>
    <div class="container row" style="max-width: 100%; text-align: center; ">
      <div class="row">
        <div class="col-lg-12">
          <div class="job-post-search-area">
            
          </div>
        </div>
      </div>
        
<?php

    if(isset($_POST["submit"]) || isset($_POST["client-name"]) ){
       $selection = $_POST["creator"];
       $client_name = '';
      $_SESSION["client_name"] = '';
       view_survey_with_client_name($conn,$selection,$client_name);
	

    }else{
        //redirect to home or surveys.php.
        header("location:surveys.php");
        exit();
    }

?>
