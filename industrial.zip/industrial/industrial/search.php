<?php
    require "database-config.php";
    require "functions.php";
    session_start();
?>
    <?php
     require "header.php"; 
    ?>
    <head>

    </head>
<!-- inner-page-banner-section start -->
  <section class="inner-page-banner-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="inner-page-banner-content text-center">
            <h2 class="title">Surveys</h2>
          </div>
          <nav aria-label="breadcrumb" class="page-header-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">surveys</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-page-banner-section end -->

  <!-- job-post-grid start  -->
  <div class="job-post-grid job-post-grid-style-one padd-top-120 padd-bottom-120">
    <form class="job-post-search-form" method="POST" action="search.php"> 
              <div class="row">
                <div class="col-lg-3">
                  
                </div>
                <div class="col-lg-3">
                  <div class="frm-group has_select">
                    <select name='creator'>
                       <?php get_User($conn);?>
                    </select>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="frm-group">
                    <input type="submit" name="submit" id="job_submit" value="search">
                  </div>
                </div>
              </div>
            </form>
    <div class="container row" style="max-width: 100%; text-align: center; ">
      <div class="row">
        <div class="col-lg-12">
          <div class="job-post-search-area">
            
          </div>
        </div>
      </div>

        
<?php

    if(isset($_POST["submit"]) || isset($_POST["client-name"]) ){
       $selection = $_POST["creator"];
       $client_name = '';
      $_SESSION["client_name"] = '';
       view_survey_with_client_name($conn,$selection,$client_name);
	

    }else{
        //redirect to home or surveys.php.
        header("location:surveys.php");
        exit();
    }

?>
</div>
</div>
<!-- footer-section start -->
  <footer class="footer-section">
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-6">
            <div class="footer-widget widget-about wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">about us</h4>
              <div class="widget-about-body">
                  <p>Find us here</p>
                  </br>
                  <a class="site-logo site-title" href="https://citycollege.sheffield.eu/frontend/index.php?chlang=GR_ENl"><img src="assets/images/Collegelogo.png" alt="site-logo"><span class="logo-icon"><i class="flaticon-fire"></i></span></a>
                  
                <ul class="social-links d-flex">
                  <li><a href="#0"><i class="fa fa-facebook-f"></i></a></li>
                  <li><a href="#0"><i class="fa fa-twitter"></i></a></li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-4 col-sm-6">
           <div class="footer-widget widget-links wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">Researchers</h4>
              <ul class="links-list">
                <li><a href="#0">Dr. Maria's research</a></li>
                <li><a href="#0">Dr. Maria's research</a></li>
                <li><a href="#0">Dr. Maria's research</a></li>
              </ul> 
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-4 col-sm-6">
            <div class="footer-widget widget-contact wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">contact us</h4>
              <div class="widget-contact-body">
                <ul>
                  <li>
                    <i class="fa fa-paper-plane"></i>
                      <a class="footer-maps" href="https://goo.gl/maps/pwwF4JmBSi8Axygx5" style="color:#92989b; text-align: inherit;">
                      
                      24, Proxenou Koromila Street,
                            546 22 Thessaloniki, Greece</a>
                  </li>
                </ul>
                  <ul>
                  <li>
                    <i class="fa fa-phone"></i>
                    <p style="font-weight:bold;">Contact us here</p>
                  </li>
                </ul>
                <a class="footer-phone" href="tel:016546545646">
                    +30 2310 224 421
                    </br>
                    +30 2310 224 521</a>
                <ul>
                  <li>
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                            <a href = "mailto: abc@bla.com" style="color:#92989b; text-align: inherit;">acadreg@citycollege.sheffield.eu</a>
                  </li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
        </div>
      </div>
    </div>

      
  </footer>
  <!-- footer-section end -->
  <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-angle-up"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->
   <script src="assets/js/jquery-3.3.1.min.js"></script>
  <!-- jquery migrate js file -->
  <script src="assets/js/jquery-migrate-3.0.0.js"></script>
  <!-- bootstrap js file -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- jquery waypoints js file -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- js file -->
  <script src="assets/js/jquery.countup.min.js"></script>
  <!-- jquery countup js file -->
  <script src="assets/js/lightcase.js"></script>
  <!-- js owl carousel file -->
  <script src="assets/js/owl.carousel.js"></script>
  <!-- wow js file -->
  <script src="assets/js/wow.min.js"></script>
  <!-- main js file -->
  <script src="assets/js/main.js"></script>
</body>
</html>