<?php
require "database-config.php";
require "functions.php";
include "header.php";
session_start();
?>
<!DOCTYPE html>
<html>

<head>

    <?php
     require "header.php"; 
    ?>
    <head>
        

    </head>
</head>

<body>
    <?php
    if (!isset($_SESSION["uid"]) && !isset($_SESSION["loggedin"])) {
        header("location: login-page.php");
        exit();
    }
    ?>

    <form action="upload-photo.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="file">
        <input type="submit" name="submit">
    </form>


<?php 
    //Maybe remove inline CSS and add general CSS for errors.
    if(isset($_GET["error"])){
        if($_GET["error"] == "wrongformat"){
            echo"<p style='color:red;'>Wrong file format."."<br><br>"." Only .jpg, .jpeg and .png files are allowed.</p>";

        }else if($_GET["error"] == "muffail"){
            echo"<p style='color:red;'>Your file couldn't be uploaded"."<br><br>"." Please try again.</p>";
        }else if($_GET["error"] == "nofile"){
            echo"<p style='color:red;'>Please select a file to upload."."<br><br>"."</p>";
        }else if($_GET["error"] == "userstmtfailed"){
            echo"<p style='color:red;'> Oops! Something went wrong.</p>";
        }else if($_GET["error"] == "surveyinputempty"){
            echo"<p style='color:red;'> Please add a Survey Link.</p>";
        }else if($_GET["error"]== "surveyexists"){
            echo"<p style = 'color:red;' > A survey already exists with the link you provided.</p>";
        }
    }
    

?>






    <?php
    $uid = $_SESSION["uid"];

    fetch_profile($conn, $uid);

    //HTMLSPECIAL CHARS FOR EVERY OUTPUT
    $name = htmlspecialchars($user_data["fname"]);
    echo $name . "<br> <br>";


    ?>
    <!-- value='echo $_GET["surveyname"];' -->

    <form action="upload-survey.php" method="POST" enctype="multipart/form-data">
        <input type="text" name="survey-link" placeholder="Link of survey"><br><br>
        <input type="text" name="survey-name" placeholder="Name of survey"><br><br>
        <textarea name="survey-desc" placeholder="Description of survey" maxlength="1024"></textarea><br><br> <!-- CHANGE DESC -->
        <input type="submit" name="submit" value="Add Survey">
    </form>




    <?php
    view_photo($conn, $uid);
    view_survey_editable($conn, $uid);


    ?>

</body>

</html>