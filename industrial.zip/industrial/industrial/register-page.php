<html>
    <?php
     require "header.php"; 
    ?>
    <head>
        

    </head>
    <body>
        

  <!-- inner-page-banner-section start -->
  <section class="inner-page-banner-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="inner-page-banner-content text-center">
            <h2 class="title">create new account</h2>
          </div>
          <nav aria-label="breadcrumb" class="page-header-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="home-one.html">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">registation</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-page-banner-section end -->

        <!-- registration-section start -->
  <section class="registration-section padd-top-120 padd-bottom-120">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="registration-block text-center">
            <div class="registration-block-inner">
              <h3 class="title">create  your account</h3>
                <div class="col-md-12">
        <form action="register.php" method="POST" enctype="multipart/form-data">
                <div class="frm-group">
                  <input type="text" name="fname" placeholder="Your first name here..." required>
                </div>
                <div class="frm-group">
                  <input type="text" name="lname" placeholder="Your last name here..."required>
                </div>
                <div class="frm-group">
                  <input type="email" name="email" placeholder="Your email here..." required>
                </div>
                
                <div class="frm-group">
                   <input type="password" name="password" placeholder="Your password here..."required>
                </div>
                <div class="frm-group">
                  <input type="password" name="password-confirm" placeholder="Retype your password..."required>
                </div>
                <div class="frm-group">
            <input type="submit" name="submit" value="Register">
                </div>
                
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
      </div>
  </section>
  <!-- registration-section end -->

        <?php

            // Showing the appropriate error based on what is returned to the URL 
            // after the user submits the information.
            // The redirect takes place inside the create_user() method inside the 
            // "functions.php" file.
            if(isset($_GET["error"])){
                if($_GET["error"]=="emailtaken"){
                    echo"<p>There is already an account with the email you gave.</p>";
                }else if($_GET["error"]=="pwdnomatch"){
                    echo"<p>Passwords do not match!<br> Make sure you type your password correctly both times.</p>";
                }else if($_GET["error"]=="userstmtfailed"){
                    echo"<p>There was an error.<br> Please try again.</p>";
                }else if($_GET["error"]=="inputempty"){
                    echo"<p>You need to fill in all the fields!</p>";
                }
            }
        ?>
        
        <!-- footer-section start -->
  <footer class="footer-section">
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-6">
            <div class="footer-widget widget-about wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">about us</h4>
              <div class="widget-about-body">
                  <p>Find us here</p>
                  <br>
                  <a class="site-logo site-title" href="https://citycollege.sheffield.eu/frontend/index.php?chlang=GR_ENl"><img src="assets/images/Collegelogo.png" alt="site-logo"><span class="logo-icon"><i class="flaticon-fire"></i></span></a>
                  
                 <ul class="social-links d-flex">
                  <li><a href="#0"><i class="fa fa-facebook-f"></i></a></li>
                  <li><a href="#0"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#0"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#0"><i class="fa fa-linkedin-square"></i></a></li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-4 col-sm-6">
           <div class="footer-widget widget-links wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">Researchers</h4>
              <ul class="links-list">
                <li><a href="#0">Dr. Maria's research</a></li>
                <li><a href="#0">Dr. Maria's research</a></li>
                <li><a href="#0">Dr. Maria's research</a></li>
              </ul> 
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-4 col-sm-6">
            <div class="footer-widget widget-contact wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">contact us</h4>
              <div class="widget-contact-body">
                <ul>
                  <li>
                    <i class="fa fa-paper-plane"></i>
                      <a class="footer-maps" href="https://goo.gl/maps/pwwF4JmBSi8Axygx5" style="color:#92989b; text-align: inherit;">
                      
                      24, Proxenou Koromila Street,
                            546 22 Thessaloniki, Greece</a>
                  </li>
                </ul>
                  <ul>
                  <li>
                    <i class="fa fa-phone"></i>
                    <p style="font-weight:bold;">Contact us here</p>
                  </li>
                </ul>
                <a class="footer-phone" href="tel:016546545646">
                    +30 2310 224 421
                    <br>
                    +30 2310 224 521</a>
                <ul>
                  <li>
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                            <a href = "mailto: abc@bla.com" style="color:#92989b; text-align: inherit;">acadreg@citycollege.sheffield.eu</a>
                  </li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
        </div>
      </div>
    </div>

 <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-angle-up"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->

  <!-- jquery library js file -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <!-- jquery migrate js file -->
  <script src="assets/js/jquery-migrate-3.0.0.js"></script>
  <!-- bootstrap js file -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- jquery waypoints js file -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- js file -->
  <script src="assets/js/jquery.countup.min.js"></script>
  <!-- jquery countup js file -->
  <script src="assets/js/lightcase.js"></script>
  <!-- js owl carousel file -->
  <script src="assets/js/owl.carousel.js"></script>
  <!-- wow js file -->
  <script src="assets/js/wow.min.js"></script>
  <!-- main js file -->
  <script src="assets/js/main.js"></script>
      
  </footer>
  <!-- footer-section end -->
    </body>

</html>
