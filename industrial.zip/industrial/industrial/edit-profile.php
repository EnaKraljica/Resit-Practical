<?php
require "database-config.php";
require "functions.php";
    session_start();
if(isset($_SESSION["uid"]) && isset($_SESSION["loggedin"])){
    if(isset($_POST["submit"])){  
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $email = $_POST["email"];
        $uid = $_SESSION["uid"];
        edit_profile($conn,$uid,$fname,$lname,$email);
    }
else{
    header("location:user-profile.php");
    exit();
}
}else{
    header("location:user-profile.php");
    exit();
}

?>
