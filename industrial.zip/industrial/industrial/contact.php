<!DOCTYPE html>
<?php
     require "header.php"; 
?>
<html lang="en">
<head>

</head>
<body>

  <!-- inner-page-banner-section start -->
  <section class="inner-page-banner-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="inner-page-banner-content text-center">
            <h2 class="title">get in touch with us</h2>
          </div>
          <nav aria-label="breadcrumb" class="page-header-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.html">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">contact</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-page-banner-section end -->

  <!-- contact-section start -->
  <section class="contact-section padd-top-120 padd-bottom-120">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="contact-item text-center">
            <div class="content">
              <h4 class="title">office address</h4>
              <p>The Psychology Department
24, Proxenou Koromila Street,
546 22 Thessaloniki, Greece</p>
            </div>
          </div>
        </div><!-- contact-item end -->
        <div class="col-lg-4">
          <div class="contact-item text-center">
            <div class="content">
              <h4 class="title">email address</h4>
              <p><a href="mailto:contact@gmail.com"> psy@hotmail.com</a></p>
                
                  <p><a href="mailto:contact@gmail.com"> career@gmail.com</a>
                </p>
            </div>
          </div>
        </div><!-- contact-item end -->
        <div class="col-lg-4">
          <div class="contact-item text-center">
            <div class="content">
              <h4 class="title">phone number</h4>
                <p>+30 2310 224 421</p>
                <p>+30 2310 224 521</p>
            </div>
          </div>
        </div><!-- contact-item end -->
      </div>
      <div class="row">
        <div class="col-lg-12">
          <div class="contact-form-area">
            <h3 class="title">send your messages</h3>
            <form class="contact-form">
              <div class="row">
                <div class="col-lg-6">
                  <div class="frm-group">
                    <input type="text" name="contact_name" id="contact_name" placeholder="Name*">
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="frm-group">
                    <input type="email" name="contact_email" id="contact_email" placeholder="Email*">
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="frm-group">
                    <textarea placeholder="Write your message"></textarea>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="frm-group">
                    <input type="submit" name="contact_submit" id="bt1" value="send message"
                    type="button">
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- contact-section end -->

 
  <!-- footer-section start -->
  <footer class="footer-section">
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-6">
            <div class="footer-widget widget-about wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">about us</h4>
              <div class="widget-about-body">
                  <p>Find us here</p>
                  </br>
                  <a class="site-logo site-title" href="https://citycollege.sheffield.eu/frontend/index.php?chlang=GR_ENl"><img src="assets/images/Collegelogo.png" alt="site-logo"><span class="logo-icon"><i class="flaticon-fire"></i></span></a>
                  
                <ul class="social-links d-flex">
                  <li><a href="#0"><i class="fa fa-facebook-f"></i></a></li>
                  <li><a href="#0"><i class="fa fa-twitter"></i></a></li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-4 col-sm-6">
           <div class="footer-widget widget-links wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">Researchers</h4>
              <ul class="links-list">
                <li><a href="#0">Dr. Maria's research</a></li>
                <li><a href="#0">Dr. Maria's research</a></li>
                <li><a href="#0">Dr. Maria's research</a></li>
              </ul> 
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-4 col-sm-6">
            <div class="footer-widget widget-contact wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">contact us</h4>
              <div class="widget-contact-body">
                <ul>
                  <li>
                    <i class="fa fa-paper-plane"></i>
                      <a class="footer-maps" href="https://goo.gl/maps/pwwF4JmBSi8Axygx5" style="color:#92989b; text-align: inherit;">
                      
                      24, Proxenou Koromila Street,
                            546 22 Thessaloniki, Greece</a>
                  </li>
                </ul>
                  <ul>
                  <li>
                    <i class="fa fa-phone"></i>
                    <p style="font-weight:bold;">Contact us here</p>
                  </li>
                </ul>
                <a class="footer-phone" href="tel:016546545646">
                    +30 2310 224 421
                    </br>
                    +30 2310 224 521</a>
                <ul>
                  <li>
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                            <a href = "mailto: abc@bla.com" style="color:#92989b; text-align: inherit;">acadreg@citycollege.sheffield.eu</a>
                  </li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
        </div>
      </div>
    </div>

      
  </footer>
  <!-- footer-section end -->
  <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-angle-up"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->

  <!-- jquery library js file -->
  <script type="text/javascript">
    $(document).ready(function() {
    $('#bt1').click(function() {
        $('#fr1').attr('action',
                       'mailto:test@test.com?subject=' +
                       $('#tb1').val() + '&body=' + $('#tb2').val());
        $('#fr1').submit();
    });
});</script>
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <!-- jquery migrate js file -->
  <script src="assets/js/jquery-migrate-3.0.0.js"></script>
  <!-- bootstrap js file -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- jquery waypoints js file -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- js file -->
  <script src="assets/js/jquery.countup.min.js"></script>
  <!-- jquery countup js file -->
  <script src="assets/js/lightcase.js"></script>
  <!-- js owl carousel file -->
  <script src="assets/js/owl.carousel.js"></script>
  <!-- wow js file -->
  <script src="assets/js/wow.min.js"></script>
  <!-- main js file -->
  <script src="assets/js/main.js"></script>
</body>
</html>