<?php
require "database-config.php";
require "functions.php";
    session_start();
if(isset($_SESSION["uid"]) && isset($_SESSION["loggedin"])){
    if(isset($_GET["link"])){  
        $survey_link = $_GET["link"];
        $uid = $_SESSION["uid"];
        delete_survey($conn,$uid,$survey_link);
    }
else{
    header("location:user-profile.php");
    exit();
}
}else{
    header("location:user-profile.php");
    exit();
}

?>
