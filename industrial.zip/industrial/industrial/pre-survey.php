
<!DOCTYPE html>
<html>
    <?php
     require "header.php"; 
    ?>
    <head>
        

    </head>
<body>
    <form action="surveys.php" method="POST" enctype="multipart/form-data">
        <div class="frm-group">
        	  
                  <input type="text" name="client-name" placeholder="Your name..." value="Anonymous">
                </div>
     
         <div class="frm-group">
         		<p><b>If you would like to remain anonymous, leave this field as it is.</b></p>
                    <input type="submit" name="submit" value="Go">

                </div>
        
        
        
    </form>
         <script src="assets/js/jquery-3.3.1.min.js"></script>
  <!-- jquery migrate js file -->
  <script src="assets/js/jquery-migrate-3.0.0.js"></script>
  <!-- bootstrap js file -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- jquery waypoints js file -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- js file -->
  <script src="assets/js/jquery.countup.min.js"></script>
  <!-- jquery countup js file -->
  <script src="assets/js/lightcase.js"></script>
  <!-- js owl carousel file -->
  <script src="assets/js/owl.carousel.js"></script>
  <!-- wow js file -->
  <script src="assets/js/wow.min.js"></script>
  <!-- main js file -->
  <script src="assets/js/main.js"></script>    
</body>
</html>
