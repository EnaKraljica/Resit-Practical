<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Experiment</title>
  <!-- viewport setup -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- lab.js library and experiment code -->
  <!-- lab.js library code -->
  <script src="lib/lab.js" data-labjs-script="library"></script>
  <script src="lib/lab.fallback.js" data-labjs-script="fallback"></script>
  <link rel="stylesheet" href="lib/lab.css">
  <!-- study code and styles -->
  <script src="script.js" defer="true"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- If you'd rather have a container with a fixed width
       and variable height, try removing the fullscreen class below -->
  <div class="container fullscreen" data-labjs-section="main">
    <main class="content-vertical-center content-horizontal-center">
      <div>
        <h2>Loading Experiment</h2>
        <p>The experiment is loading and should start in a few seconds</p>
      </div>
    </main>
  </div>

  <a href="../surveys.php">Back</a>
</body>
</html>
