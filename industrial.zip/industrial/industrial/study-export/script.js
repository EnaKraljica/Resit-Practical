// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.Transmit",
      "url": "backend.php",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": -140,
          "angle": 0,
          "width": 779.29,
          "height": 127.46,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "#000000",
          "text": "\nWelcome to the Stropop experiment!\nIn this experiment, your task will be to indetify the color of the word shown on the screen\nthe word itself is not important - you can ignore it.\n",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": "20",
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": -14,
          "top": -10,
          "angle": 0,
          "width": 728.43,
          "height": 67.53,
          "stroke": "#000000",
          "strokeWidth": 1,
          "fill": "#000000",
          "text": "\nTo indicate the color of the word, please use the keys r,g,b,y for red, green, blue and yellow.\nPlease answer quickly, and as accuratley as you can.",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": "18",
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 0,
          "top": -250,
          "angle": 0,
          "width": 176.03,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Stroop task",
          "fontStyle": "normal",
          "fontWeight": "bold",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 0,
          "top": 175,
          "angle": 0,
          "width": 615.44,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "please click anywhere on the sreen to start ",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "click": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instruction"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "word": "red",
          "color": "blue"
        },
        {
          "word": "green",
          "color": "yellow"
        },
        {
          "word": "blue",
          "color": "green"
        },
        {
          "word": "yellow",
          "color": "red"
        },
        {
          "word": "red",
          "color": "yellow"
        },
        {
          "word": "red",
          "color": "green"
        },
        {
          "word": "red",
          "color": "red"
        },
        {
          "word": "green",
          "color": "green"
        },
        {
          "word": "green",
          "color": "red"
        },
        {
          "word": "green",
          "color": "blue"
        },
        {
          "word": "blue",
          "color": "blue"
        },
        {
          "word": "blue",
          "color": "red"
        },
        {
          "word": "blue",
          "color": "yellow"
        },
        {
          "word": "yellow",
          "color": "blue"
        },
        {
          "word": "yellow",
          "color": "green"
        },
        {
          "word": "yellow",
          "color": "yellow"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {},
      "responses": {},
      "parameters": {},
      "messageHandlers": {},
      "title": "Task",
      "timeout": "20000",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {},
        "parameters": {},
        "messageHandlers": {},
        "title": "trial",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "rect",
                "left": 0,
                "top": -17,
                "angle": 0,
                "width": 496,
                "height": 370,
                "stroke": "#000000",
                "strokeWidth": 0,
                "fill": "#dddddd"
              },
              {
                "type": "i-text",
                "left": 0,
                "top": -25,
                "angle": 0,
                "width": 279.27,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "${parameters.color}",
                "text": "${parameters.word}",
                "fontStyle": "normal",
                "fontWeight": "bold",
                "fontSize": "38",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "keypress(r)": "red",
              "keypress(g)": "green",
              "keypress(b)": "blue",
              "keypress(y)": "yellow"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Stimulus",
            "timeout": "20000"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {},
            "parameters": {},
            "messageHandlers": {},
            "title": "inter stimulus",
            "timeout": "500"
          }
        ]
      }
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 613.64,
          "height": 120.05,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Thank you for taking part in this experiment\nYou did a great job!\n",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(q)": "continue"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Thank you "
    }
  ]
})

// Let's go!
study.run()
