<!DOCTYPE html>
<?php
     require "header.php"; 
?>
<html lang="en">
<head>

</head>
<body>

  <!-- preloader start -->
  <div id="preloader"></div>
  <!-- preloader end -->

 

  <!-- banner-section start -->
  <section class="banner-section banner-section-style-two">
    <div class="banner-slider owl-carousel">
      <div class="banner-slide has_bg_image" data-background="assets/images/banner-one.jpg"></div>
      <div class="banner-slide has_bg_image" data-background="assets/images/banner-two.jpg"></div>
      <div class="banner-slide has_bg_image" data-background="assets/images/banner-three.jpg"></div>
      
    </div>
    <div class="banner-content-area">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-10">
            <div class="banner-content text-center">
              <h2 class="title">The Psychology Department of CITY College has excellent reputation due to the high quality of teaching and research. Our academic staff is strongly committed to excellence in research and in teaching at both undergraduate and postgraduate level. </h2>
            `<p></p>
              </div>
         
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- banner-section end -->

 

  <!-- overview-section start -->
  <section class="overview-section padd-bottom-120">
    <div class="container">
      <div class="row">
       
        <div class="col-lg-12">
          <div class="company-overview-part wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
            <h2 class="block-title">Dedicated to serving the community through its teaching and research, the department extends its activities with two innovative community services:</h2>
            <div class="company-overview-item-wrapper">
              <div class="row">
                <div class="col-lg-6 col-sm-6">
                  <div class="company-overview-item">
                    <h4 class="title">The Community Counselling Centre which is open to the public</h4>
                  </div>
                </div><!-- company-overview-item end -->
                <div class="col-lg-6 col-sm-6">
                  <div class="company-overview-item">
                    <h4 class="title">E-help - an online service through which the Psychology Department offers free psychological support through the Internet. </h4>
                  </div>
                </div><!-- company-overview-item end -->
              </div>
            </div>
        </div>
        </div>
      </div>
    </div>
  </section>
  <!-- overview-section end -->

  <!-- counter-section start  -->
  <div class="counter-section has_bg_image" data-background="assets/images/bg-1.jpg">
    <div class="container">
    </div>
  </div>
  <!-- counter-section end  -->



  

  <!-- cta-section start- -->
  <section class="cta-section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-7">
          <div class="cta-content text-center">
            <h4 class="title">Research represents the backbone of our philosophy and practice. We are committed to quality academic research, pursuing innovation and building up the knowledge capacity in the region of South East Europe and beyond.</h4>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- cta-section end- -->

  

  <!-- team-section start -->
  <section class="team-section padd-top-120 padd-bottom-120">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="section-header text-center">
            <h2 class="section-title">our researchers</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 col-sm-6">
            <div class="team-single wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
            <div class="thumb">
              <img src="assets/images/dr_maria.jpg" alt="image">
              
            </div>
            <div class="content">
              <h5 class="name"><a href="researchers.php">Dr Maria Tziraki</a></h5>
              <span class="designation">Academic Director of Postgraduate Programmes in Neuropsychology</span>
            </div>
          </div>
        </div><!-- team-single end -->
        <div class="col-lg-4 col-sm-6">
            <div class="team-single wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
            <div class="thumb">
              <img src="assets/images/dr_maria.jpg" alt="image">
              
            </div>
            <div class="content">
              <h5 class="name"><a href="researchers.php">Dr Maria Tziraki</a></h5>
              <span class="designation">Academic Director of Postgraduate Programmes in Neuropsychology</span>
            </div>
          </div>
        </div><!-- team-single end -->
         <div class="col-lg-4 col-sm-6">
            <div class="team-single wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
            <div class="thumb">
              <img src="assets/images/dr_maria.jpg" alt="image">
              
            </div>
            <div class="content">
              <h5 class="name"><a href="researchers.php">Dr Maria Tziraki</a></h5>
              <span class="designation">Academic Director of Postgraduate Programmes in Neuropsychology</span>
            </div>
          </div>
        </div><!-- team-single end -->
        <!-- team-single end -->
      </div>
    </div>
  </section>
  <!-- team-section end -->

  <!-- cta-post-job-section start -->
  <section class="cta-post-job-section">
    <div class="container">
      <div class="row justify-content-between align-items-md-center">
        <div class="col-lg-7 col-md-8">
          <div class="content">
            <h2 class="title">Want to participate in our survey?</h2>
              <p><a href="surveys.php" >  Click here</a></p>
          </div>
        </div>
        <div class="col-lg-3 col-md-4 text-lg-right">
        </div>
      </div>
    </div>
  </section>
  <!-- cta-post-job-section end -->
<section class="padd-top-120">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-12">
          <div class="section-header text-center">
            <h2 class="section-title">Available surveys</h2>
          </div>
       <div class="row survey-row">   
           <div class="col-5 survey-col">
              <h6><b>Survey Name</b></h6>Stroop experiment<br><br>
               <h6>Survey Link</h6><a href="#">https://www.workadu.com</a><br><br>
                <h6>Description</h6>This is a survey       </div>

           <div class="col-5 survey-col">
              <h6><b>Survey Name</b></h6>Stroop experiment<br><br>
               <h6>Survey Link</h6><a href="#">https://www.workadu.com</a><br><br>
                <h6>Description</h6>This is a survey     </div>

           <div class="col-5 survey-col">
              <h6><b>Survey Name</b></h6>Stroop experiment<br><br>
               <h6>Survey Link</h6><a href="#">https://www.workadu.com</a><br><br>
                <h6>Description</h6>This is a survey        </div>
                <div class="col-5 survey-col">
              <h6><b>Survey Name</b></h6>Stroop experiment<br><br>
               <h6>Survey Link</h6><a href="#">https://www.workadu.com</a><br><br>
                <h6>Description</h6>This is a survey        </div>

           
</div>
        </div>
      </div>
      </div>
      </section>
 


 
  <!-- footer-section start -->
  <footer class="footer-section">
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-6">
            <div class="footer-widget widget-about wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">about us</h4>
              <div class="widget-about-body">
                  <p>Find us here</p>
                  </br>
                  <a class="site-logo site-title" href="https://citycollege.sheffield.eu/frontend/index.php?chlang=GR_ENl"><img src="assets/images/Collegelogo.png" alt="site-logo"><span class="logo-icon"><i class="flaticon-fire"></i></span></a>
                  
                 <ul class="social-links d-flex">
                  <li><a href="#0"><i class="fa fa-facebook-f"></i></a></li>
                  <li><a href="#0"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#0"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#0"><i class="fa fa-linkedin-square"></i></a></li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-4 col-sm-6">
           <div class="footer-widget widget-links wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">Researchers</h4>
              <ul class="links-list">
                <li><a href="#0">Dr. Maria's research</a></li>
                <li><a href="#0">Dr. Aristea's research</a></li>
                <li><a href="#0">Dr. Maria's research</a></li>
              </ul> 
            </div>
          </div><!-- footer-widget end -->
          <div class="col-lg-4 col-sm-6">
            <div class="footer-widget widget-contact wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
              <h4 class="widget-title">contact us</h4>
              <div class="widget-contact-body">
                <ul>
                  <li>
                    <i class="fa fa-paper-plane"></i>
                      <a class="footer-maps" href="https://goo.gl/maps/pwwF4JmBSi8Axygx5" style="color:#92989b; text-align: inherit;">
                      
                      24, Proxenou Koromila Street,
                            546 22 Thessaloniki, Greece</a>
                  </li>
                </ul>
                  <ul>
                  <li>
                    <i class="fa fa-phone"></i>
                    <p style="font-weight:bold;">Contact us here</p>
                  </li>
                </ul>
                <a class="footer-phone" href="tel:016546545646">
                    +30 2310 224 421
                    </br>
                    +30 2310 224 521</a>
                <ul>
                  <li>
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                            <a href = "mailto: abc@bla.com" style="color:#92989b; text-align: inherit;">acadreg@citycollege.sheffield.eu</a>
                  </li>
                </ul>
              </div>
            </div>
          </div><!-- footer-widget end -->
        </div>
      </div>
    </div>

      
  </footer>
  <!-- footer-section end -->
  <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-angle-up"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->

  <!-- jquery library js file -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <!-- jquery migrate js file -->
  <script src="assets/js/jquery-migrate-3.0.0.js"></script>
  <!-- bootstrap js file -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- jquery waypoints js file -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- js file -->
  <script src="assets/js/jquery.countup.min.js"></script>
  <!-- jquery countup js file -->
  <script src="assets/js/lightcase.js"></script>
  <!-- js owl carousel file -->
  <script src="assets/js/owl.carousel.js"></script>
  <!-- wow js file -->
  <script src="assets/js/wow.min.js"></script>
  <!-- main js file -->
  <script src="assets/js/main.js"></script>
</body>
</html>
