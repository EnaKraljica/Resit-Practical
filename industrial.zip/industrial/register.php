<?php 
require "database-config.php";
require "functions.php";
?>
<!DOCTYPE html>
<html>

    <head></head>
    <body>

        <?php
        if(isset($_POST["submit"])){
        //Taking the user input.
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $pwdretype = $_POST["password-confirm"];
        $defaultPic = "images/default_profile.png";
        // All the necessary checks and error handling
        // is done inside this function which makes use of 
        // other functions implemented inside "functions.php".
      
        create_user($conn,$fname,$lname,$email,$password,$pwdretype,$defaultPic);
        }else{
            header("location: register-page.php");
            
        }
           ?>


    </body>
    </html>                                                                     