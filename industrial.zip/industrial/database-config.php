<?php 
$servername = "localhost";
$username = "root";
$password="server";
$dbname ="ip_db";
$conn = mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    die("connection failed");
}
?>