<?php
// Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

/*
  @return
    True if email exists 
    False if it doesn't
*/
function emailExists($conn, $email)
{
    $sql = "SELECT * FROM users WHERE email=?;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:register-page.php?error=emailstmtfailed");
        exit();
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    return $result = ($row = $result->fetch_assoc())?true:false;
}

/*
  @return
    False is passwords don't match
    True if they match
*/
function passwordsMatch($pwd, $repeat_pwd)
{
    return $result = ($pwd !== $repeat_pwd)?false:true;
}


/*
  @return
   True if either of the parameters is empty
   False if none is empty
*/
function emptyRegisterInput($fname, $lname, $email, $pwd, $repeat_pwd)
{
    $result = false;
    if (empty($fname) || empty($lname) || empty($email) || empty($pwd) || empty($repeat_pwd)) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}


function emptyLoginInput($email, $password)
{
    $result = false;
    if (empty($email) || empty($password)) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}



function create_user($conn, $fname, $lname, $email, $pwd, $repeat_pwd,$default_photo)
{
    //If all the conditions are met, add the new user to the DB
    if (emailExists($conn, $email) !== true && passwordsMatch($pwd, $repeat_pwd) !== false && emptyRegisterInput($fname, $lname, $email, $pwd, $repeat_pwd) !== true &&
    is_valid_register_input($conn,$fname,$lname,$pwd,$repeat_pwd)!== false && is_email_valid($email) !== false) {
      
        $sql = "INSERT INTO users(fname,lname,email,upassword,profile_pic) VALUES(?,?,?,?,?);";
        $stmt = $conn->stmt_init();
        if (!$stmt->prepare($sql)) {
            header("location:register-page.php?error=userstmtfailed");
            exit(); 
        }
        //hashing the password before sending it to the database.
        $hash_pwd = password_hash($pwd, PASSWORD_DEFAULT);

        $stmt->bind_param("sssss", $fname, $lname, $email, $hash_pwd,$default_photo);
        $stmt->execute();
        $stmt->close();
        //Redirect the user to login page with no error.
        header("location:login-page.php?error=none"); 
    } else if (emailExists($conn, $email) !== false) {
        // If the email exists, redirect the user to register page with emailtaken error and his info.
        header("location:register-page.php?error=emailtaken&fname=$fname&lname=$lname");
        exit();
    } else if (passwordsMatch($pwd, $repeat_pwd) !== true) {
         // If the passwords don't match, redirect the user to register page with pwdnomatch error and his info.
        header("location:register-page.php?error=pwdnomatch&fname=$fname&lname=$lname&email=$email");
        exit();
    } else if(emptyRegisterInput($fname, $lname, $email, $pwd, $repeat_pwd) !== false){
        // If input is emtpy, redirect the user to register page with inputempty error.
        header("location:register-page.php?error=inputempty");
        exit();
    }else if(is_valid_register_input($conn,$fname,$lname,$pwd,$repeat_pwd)!== true){
        // If input is not valid, redirect the user to register page with specialchars error and his info.
        header("location:register-page.php?error=specialchars&fname=$fname&lname=$lname&email=$email");
        exit();
    }
    else{
         // If the email is not valid, redirect the user to register page with invalidemail error and his info.
        header("location:register-page.php?error=invalidemail&fname=$fname&lname=$lname");
        exit();
    }
}
function loginUser($conn, $email, $password)
{
    if (emptyLoginInput($email, $password) !== true && is_email_valid($email) !== false) {
        $sql = "SELECT * FROM users WHERE email=?;";
        $stmt = $conn->stmt_init();
        if (!$stmt->prepare($sql)) {
            header("location:login-page.php?error=userstmtfailed");
            exit();
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $dbemail = $row["email"]; //Get the email from the database
        $dbpwd = $row["upassword"]; //Get the password from the database
        $pwd_check = password_verify($password, $dbpwd); //Check if the password from login is the same as the database password.
        if ($pwd_check !== true) {
            //If the passwords don't match redirect back to login-page with wrongcredentials error.
            header("location:login-page.php?error=wrongcredentials&email=$email");
            exit();
        } else {
            //Starting the session and saving session variables on successfull login.
            session_start(); 
            $_SESSION["uid"] = $row["user_id"];
            $_SESSION["fullname"] = $row["fname"] ." ". $row["lname"];
            $_SESSION["loggedin"] = true;
            header("location:user-profile.php");
            exit();
        }
    }else if(is_email_valid($email) !== true){
        header("location:login-page.php?error=invalidemail&email=$email");
        exit();
    }
    else {
        header("location:login-page.php?error=inputempty");
        exit();
    }
}



/*
   @param
    Connection and the user id that is taken from the session variable
    that was stored when the user logged in.
*/
function upload_photo($conn,$uid)
{
    $targetDir = "images/"; //Name of directory
    $fileName = basename($_FILES["file"]["name"]); //Name of the uploaded file
    $targetFilePath = $targetDir . $fileName; //Full path ("images/test.jpeg" for example)
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION)); //Type of file
    
    if (!empty($_FILES["file"]["name"])) {
        //The file formats that are allowed.
        $allowTypes = array('jpg', 'png', 'jpeg');         

        if (in_array($fileType, $allowTypes)) { //If the file type is allowed, add the image to the DB
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)) {
                $sql = "UPDATE users SET profile_pic=? WHERE user_id=?";
                $stmt = $conn->stmt_init();
                if (!$stmt->prepare($sql)) {
                    header("location:user-profile.php?error=userstmtfailed");
                    exit();
                }
                $stmt->bind_param("si", $targetFilePath, $uid);
                $stmt->execute();
                $stmt->close();
                header("location:user-profile.php?error=none");
                exit();
            } else {
                //muf = [M]ove [U]ploaded [F]ile fail
                //throw a general error
                header("location:user-profile.php?error=muffail");
                exit(); 
            }
        } else {
            header("location:user-profile.php?error=wrongformat");
            exit();
        }
    } else {
        header("location:user-profile.php?error=nofile");
        exit();
    }
}


/*
    @param
    Connection and user id taken from the session variable.

    Shows the profile photo the user uploaded
    When a user registers a default photo is assigned
*/
function view_photo($conn,$uid)
{
    $sql = "SELECT profile_pic FROM users WHERE user_id=?;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $img_url = $row["profile_pic"];
    echo "<img src='$img_url' width=25%; height=25%;/>"; //remove the inline CSS after.
   
    
}


//Show all the profile information of the user

//TODO: ADD ALL THE @PARAMS IN SELECT QUERY
function fetch_profile($conn,$uid){
    // $user_data needs to be global here so it can be accessed through user-profile.php
    // The alternative is to not have the fetch_profile() as a method and just call this code
    // through user-profile.php. I don't know what's best yet.
    global $user_data;
    $sql = "SELECT fname, lname,email FROM users WHERE user_id=?;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $result = $stmt->get_result();
    $user_data = $result->fetch_assoc();
 
    
    
}


function is_survey_input_empty($survey_link){

    return (empty($survey_link))?true:false;
}


/*
    @param
    The id of the user (session) and the link of the survey

Check if a survey exists for the specific user

*/
function survey_exists($conn,$uid,$link){
    $exists = false;
    $sql = "SELECT survey_name, survey_id FROM survey WHERE survey_link=? AND creator_id=?;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->bind_param("si", $link,$uid);
    $stmt->execute();
    $stmt->store_result();
    $nrows = $stmt->num_rows;

    if($nrows>0){
        $exists = true;
    }else{
        $exists = false;
    }
    return $exists;

    /*$result = $stmt->get_result();
    $row = $result->fetch_assoc();*/
   

    
}


/*
    @param
    Name, link and survey description

    @return 
    False if any of the special characters exists in the name and description
    and also false if the link is not a valid url

    True if all conditions are met
*/
function is_survey_input_valid($conn,$name,$link,$desc){
    //preg_match('/[><>*;]/',$link)
    //|| !preg_match('/\bhttp\b/',$link) ||!preg_match('/\bhttps\b/',$link) 
    $result = false;
    if(preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/',$name)|| !filter_var($link, FILTER_VALIDATE_URL) || preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/',$desc)){
        $result = false;
    }else{
        $result = true;
    }
    return $result;
    
}




function upload_survey($conn,$uid,$name,$link,$desc){
    if(is_survey_input_empty($link)!== true && survey_exists($conn,$uid,$link)!== true && is_survey_input_valid($conn,$name,$link,$desc) !== false){
    $sql = "INSERT INTO survey(creator_id,survey_name,survey_link,description) VALUES(?,?,?,?);";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->bind_param("isss", $uid,$name,$link,$desc);
    $stmt->execute();
    $stmt->close();
    header("location:user-profile.php?error=none");
    exit();
    }else if(is_survey_input_empty($link)!== false){
        header("location:user-profile.php?error=surveyinputempty");
        exit(); 
    }
    else if(survey_exists($conn,$uid,$link)!== false){
        header("location:user-profile.php?error=surveyexists&surveyname=$name&surveylink=$link&surveydesc=$desc");
        exit(); 
    }
    else{
        header("location:user-profile.php?error=surveyinputinvalid&surveyname=$name&surveylink=$link&surveydesc=$desc");
        exit();      
    }
}


/*Checking if the register input
  contains special characters.
  If it contains special characters, it means the input is not valid.
*/
function is_valid_register_input($conn,$fname,$lname,$pwd,$repeat_pwd){
    $result = false;
    if(preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬;-]/',$fname)|| 
        preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬;-]/',$lname)|| 
        preg_match('/[><>;]/',$pwd) || 
        preg_match('/[><>;]/',$repeat_pwd)){
        $result = false;
    }else{
        $result = true;
    }
    return $result;
    
}

//Weird problem here as mentioned above in the create_user function
function is_email_valid($email){
   return (filter_var($email, FILTER_VALIDATE_EMAIL))?true:false;

   
} 

// CHANGE THIS TO SHOW SURVEY TO USERS BASED ON THE NAME THEY CLICKED
function view_survey($conn,$uid){
    // WORKS FINE BUT I NEED TO SEE IF I CAN USE A METHOD FOR THIS. GLOBAL VARIABLE IS STILL A PROBLEM
    // ADD MESSAGE "PROVIDE FULL URL(https://..."
    $sql = "SELECT * FROM survey WHERE creator_id=?;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->bind_param("i",$uid);
    $stmt->execute();
    $result = $stmt->get_result();
    $nrows = $result->num_rows;

    if($nrows>0){
    while($user_data = $result->fetch_assoc()){
    $link = $user_data["survey_link"];
 
    //echo'<input type="checkbox" name="chkl[ ]" value="ss">';s
    echo"<form action='delete-survey.php' method='POST'>";
    echo "<section style ='border-style:solid; margin-top:50px;width:300px;'>";
    
    echo "<br><br><br>";
    echo "Survey name: ".$user_data["survey_name"]."<br><br>";
    echo "<a name='link_to_delete' href = '$link' target = '_blank' > Survey Link </a>"."<br><br>";
    echo "Survey description: ".$user_data["description"]."<br><br>";
    echo "</section>";
    echo "</form>";
}
}else{
    echo"No surveys yet...";
}
}


function view_survey_with_client_name($conn,$uid,$client_name){
    // WORKS FINE BUT I NEED TO SEE IF I CAN USE A METHOD FOR THIS. GLOBAL VARIABLE IS STILL A PROBLEM
    // ADD MESSAGE "PROVIDE FULL URL(https://..."
    $sql = "SELECT * FROM survey WHERE creator_id=?;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->bind_param("i",$uid);
    $stmt->execute();
    $result = $stmt->get_result();
    $nrows = $result->num_rows;

    if($nrows>0){
    while($user_data = $result->fetch_assoc()){
    $link = $user_data["survey_link"];
    $link = $link . "?name=$client_name";
    //echo'<input type="checkbox" name="chkl[ ]" value="ss">';s
    echo"<form action='delete-survey.php' method='POST' class='col-sm-4'>";
    echo "<section style ='border-style:solid; margin-top:50px;'>";
    
    echo "<br><br><br>";
    echo "Survey name: ".$user_data["survey_name"]."<br><br>";
    echo "<a name='link_to_delete' href = '$link' target = '_blank' > Survey Link </a>"."<br><br>";
    echo "<a name='link_to_delete' href = 'stroop/download.php' target = '_blank' > Download </a>"."<br><br>";
    echo "Survey description: ".$user_data["description"]."<br><br>";
    echo "</section>";
    echo "</form>";
}
}else{
    echo"No surveys yet...";
}
}


function get_User($conn){
    // WORKS FINE BUT I NEED TO SEE IF I CAN USE A METHOD FOR THIS. GLOBAL VARIABLE IS STILL A PROBLEM
    // ADD MESSAGE "PROVIDE FULL URL(https://..."
    $sql = "SELECT * FROM users";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
   // $stmt->bind_param("i",$uid);
    $stmt->execute();
    $result = $stmt->get_result();
    $nrows = $result->num_rows;

 while($user_data = $result->fetch_assoc()){
 
    //echo'<input type="checkbox" name="chkl[ ]" value="ss">';s
    echo '<option value="'.$user_data["user_id"].'">'.$user_data["fname"] . ' '. $user_data["lname"].'</option>';
    
}

        //$user_data = $result->fetch_assoc();
}

/*
    Prints all the surveys of a specific user given his ID
    and allows the user to edit them by changing the input fields,
    the values of which are populated by default by the data from the DB.
*/
function view_survey_editable($conn,$uid){
    // ADD MESSAGE "PROVIDE FULL URL(https://..."
    $sql = "SELECT * FROM survey WHERE creator_id=?;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->bind_param("i",$uid);
    $stmt->execute();
    $result = $stmt->get_result();
    while($user_data = $result->fetch_assoc()){
    $link = $user_data["survey_link"];
    $name = $user_data["survey_name"];
    // This is pretty ugly to look at :)
    //section style ='border-style:solid; margin-top:50px;width:300px;'
    echo"<form action='edit-survey.php' method='POST' enctype='multipart/form-data'>";
    echo "<section>";
    echo "<br><br><br>";
    echo "Survey name: "."<input type='text' name='survey-name' value='$name' maxlength='250'><br><br>";
    echo "<a href = '$link' target = '_blank' > Survey Link </a>"."<br><br>";
    echo "Survey link: "."<input type='text' name='survey-link' value=".$link."><br><br>";
    echo "Survey description: "."<textarea name='survey-desc' maxlength='1024'>".$user_data["description"]."</textarea>"."<br><br>";
    echo "<input type='submit' name='edit' value='Save changes'>";
    echo "<a href ='delete-survey.php?link=$link'> Delete Survey </a>"."<br><br>";
    echo "</section>";
    echo "</form>";
}
}



/*
    Delete a specific survey based on the user ID 
    and the survey link.
*/
function delete_survey($conn,$uid,$survey_link){
    $sql = "DELETE FROM survey WHERE creator_id=? AND survey_link=?;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->bind_param("is",$uid,$survey_link);
    $stmt->execute();
    $stmt->get_result();
    header("location:user-profile.php?error=none");
    exit();
}



function edit_survey($conn,$uid,$survey_name,$survey_link,$survey_desc){
    if(is_survey_input_valid($conn,$survey_name,$survey_link,$survey_desc)!== false && is_survey_input_empty($survey_link)!== true){
    $sql = "UPDATE survey SET survey_name=?, survey_link=?, description=? WHERE creator_id=? AND survey_link =?;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->bind_param("sssis",$survey_name,$survey_link,$survey_desc,$uid,$survey_link);
    $stmt->execute();
    $status = $stmt->execute();
    if($status === false){
    header("location:user-profile.php?error=editerror");
    exit();
    }
    header("location:user-profile.php?error=none");
    exit();
}else{
    header("location:user-profile.php?error=invalidinput");
    exit();
}
}

function edit_profile($conn,$uid,$fname,$lname,$email){
   
    $sql = "UPDATE users SET fname='$fname', lname='$lname', email='$email' WHERE user_id= $uid ;";
    $stmt = $conn->stmt_init();
    if (!$stmt->prepare($sql)) {
        header("location:user-profile.php?error=userstmtfailed");
        exit();
    }
    $stmt->execute();
    $status = $stmt->execute();
    if($status === false){
    header("location:user-profile.php?error=editerror");
    exit();
    }
    header("location:user-profile.php?error=none");
    exit();

}

/* 
    --------------------------------------------------------------------------------
    CODE TO AUTOFILL NAVIGATION BAR DROP DOWN MENU WITH THE NAMES OF THE PROFESSORS.
    --------------------------------------------------------------------------------

$sql = "SELECT * FROM users WHERE user_id>?;";   
        $stmt = $conn->stmt_init();
        if (!$stmt->prepare($sql)) {
            header("location:login-page.php?error=userstmtfailed");
            exit();
        }
        $i=0;
        $stmt->bind_param("i", $i);
        $stmt->execute();
        $result = $stmt->get_result();
        

        while($row = $result->fetch_assoc()){
            echo'<li>'.$row["fname"].'</li>';
        }

*/



    
